#include <stdio.h>
#include <conio.h>

int main() {
       int i, Tab[5];
       for(i=0; i<5;i++) Tab[i]=i;
       
       for(i=0; i<5;i++) printf("%d ",Tab[i]);
       printf("\n");
       i=0;
       Tab[++i]=5; // najpierw inkrementacja, potem podstawienie
       for(i=0; i<5;i++) printf("%d ",Tab[i]);
       getche();
       return 0;
}
